#PBS -q workq
#PBS -j oe
#PBS -N fast
# use 1 nodes and 24 cores in each node
#PBS -l nodes=1:ppn=24
#PBS -l walltime=90:00:00
#PBS -V

cd $PBS_O_WORKDIR

#module load OpenFAST/dev-18Aug2020
module load OpenFAST/pull537
module load python/3.5.6

python3.5 runDLC.py input.txt

#openfast 5MW_Land_ModeShapes-4.fst |& stdbuf -oL tr '\r' '\n' > sim-4.log
#openfast 5MW_Land_ModeShapes-5.fst |& stdbuf -oL tr '\r' '\n' > sim-5.log 
#wait
