import os,sys, getopt, re
import fileinput, logging
from shutil import copyfile
import numpy as np
import multiprocessing
import subprocess
import shlex
from multiprocessing.pool import ThreadPool

logging.basicConfig(filename='datalog.txt', filemode='w',format='%(asctime)s - %(message)s', level=logging.INFO)

CASEDIR=os.getcwd()

def readInputParams(inputFile):
    d = {}
    if os.path.isfile(inputFile)!=True:
        print(inputFile, ' file does not exit!')
        exit()

    with open(inputFile) as f:
        for line in f:
            if line.startswith('#') or line=='\n':
                continue
            line=line.strip() # remove whitespaces for each line  
            line=line.split('#')[0] # ignore text after # character
            key = line.split('=')[0] # split the line by = and take the first string as key
            val = line.split('=')[1] # split the line by = and take the second string as value(s)
            val = [x.strip() for x in val.split(',')]
            d[key] = val
            
    TemplateFile=d['InputFile'][0]
    WindSpeedAry=d['WindSpeed_[m/s]']
    RotSpeedAry=d['RotorSpeed_[rpm]']
    BldPitch1Ary=d['PitchAngle_[deg]']
    GenTqAry=d['GeneratorTorque_[Nm]']
    SimTime=float(d['SimTime_[s]'][0])
    RatedWindSpeed=float(d['RatedWindSpeed_[m/s]'][0])

    WindSpeedAry=[float(i) for i in WindSpeedAry]
    RotSpeedAry=[float(i) for i in RotSpeedAry]
    BldPitch1Ary=[float(i) for i in BldPitch1Ary]
    GenTqAry=[float(i) for i in GenTqAry]

    return TemplateFile, WindSpeedAry, RotSpeedAry, BldPitch1Ary, GenTqAry, SimTime, RatedWindSpeed

def runOpenFAST(args):
    #OPENFAST="/soft/opensoft/OpenFAST/dev/build/bin/"
    CMNDARGS=os.getenv('OPENFAST') + ' ' + os.getcwd()+'/'+ args
    p = subprocess.Popen(CMNDARGS, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    out, err = p.communicate()
    # this output and error are not working yet when shell is True in Popen command
    return (args, out.decode('utf-8'), err.decode('utf-8'))

def SetFASTPar(infile,var,val):
    flag=0

    Dtype=type(val)
    if(Dtype==np.float64 or Dtype==int or Dtype==float or Dtype==np.int64):
        val='{:11g}'.format(val)
    elif var=="LinTimes":
        val=val;
    else:
        if(len(str(val))<=11):
            val='{:11s}'.format(val)
        else:
            val='"'+val+'"'

    #if var in line and flag==0:
    for line in fileinput.input(infile, inplace=True):
        if var=='BlPitch(1)' or var=='BlPitch(2)' or var=='BlPitch(3)':
            if var in line and flag==0:
                line=val+" "+line.lstrip().split(" ",1)[1]
                #print("After editing %s %s %d" %(line,var,ind))
                flag=1
        else:
            if re.search(r'\b%s\b' % var,line) and flag==0:
                line=val+" "+line.lstrip().split(" ",1)[1]
                #print("After editing %s %s %d" %(line,var,ind))
                flag=1
        sys.stdout.write(line)
    
    if flag==0:
        print('Parameter %s not found; adding it to data structure.' %(var))


FASTTemplateFile,WindSpeedAry,RotSpeedAry,BldPitch1Ary,GenTqAry,SimTime,RatedWindSpeed=readInputParams(sys.argv[1])
# # speed in m/s
# WindSpeedAry=np.array([4, 6, 8, 10, 12, 14, 16])
# # rotational speed in rpm
# RotSpeedAry=np.array([5.0,  5.0, 6.0, 7.0, 7.56, 7.56, 7.56])
# # angle in deg
# BldPitch1=np.array([3, 2, 0, 0, 5.5, 10, 12.8])
# # torquie in N-m
# #GenTqAry=np.array([0, 0.606, 2.58, 9.686, 20.174, 31.455, 43.094, 43.094])
# GenTqAry=np.array([1.5, 5.0, 11.8, 17.5, 11.98, 11.98, 11.98])
# GenTqAry=GenTqAry*1000000;

# # speed in m/s
# WindSpeedAry=np.array([3, 4, 5])
# # rotational speed in rpm
# RotSpeedAry=np.array([6.972, 7.183, 7.506])
# # angle in deg
# BldPitch1=np.array([0, 0, 0])
# # torquie in N-m
# GenTqAry=np.array([0.606, 2.58, 5.611])
# GenTqAry=GenTqAry*1000;

CompElast=0 
CompInflow=0
CompAero=0   
CompServo=0 
CompHydro=0 
CompServo=0    
CompMooring=0
CompIce=0

#create an empty Dictionary to store list of used input files
usedFiles={}
commonFiles={}
alterFiles={}
fh=open(FASTTemplateFile, 'r')
for line in fh:
    if 'CompAero' in line:
        CompAero=1
    if 'CompInfow' in line:
        CompInflow=1
    if 'CompServo' in line:
        CompServo=1
    if 'CompElast' in line:
        CompElast=1
    if 'EDFile' in line:
        EDTemplateFile=line.split(" ")[0].strip('"')
        if(EDTemplateFile!='unused'):
            usedFiles['EDFile']=EDTemplateFile
    if 'InflowFile' in line:
        InflowTemplateFile=line.split(" ")[0].strip('"')
        if(InflowTemplateFile!='unused'):
            usedFiles['InflowFile']=InflowTemplateFile
    if 'ServoFile' in line:
        ServoTemplateFile=line.split(" ")[0].strip('"')
        if(ServoTemplateFile!='unused'):
            usedFiles['ServoFile']=ServoTemplateFile
    if 'AeroFile' in line:
        AeroTemplateFile=line.split(" ")[0].strip('"')
        if(AeroTemplateFile!='unused'):
            usedFiles['AeroFile']=AeroTemplateFile
    if 'BDBldFile(1)' in line:
        Bld1TemplateFile=line.split(" ")[0].strip('"')
        if(Bld1TemplateFile!='unused'):
            usedFiles['BDBldFile(1)']=Bld1TemplateFile
    if 'BDBldFile(2)' in line:
        Bld2TemplateFile=line.split(" ")[0].strip('"')
        if(Bld2TemplateFile!='unused'):
            usedFiles['BDBldFile(2)']=Bld2TemplateFile
    if 'BDBldFile(3)' in line:
        Bld3TemplateFile=line.split(" ")[0].strip('"')
        if(Bld3TemplateFile!='unused'):
            usedFiles['BDBldFile(3)']=Bld3TemplateFile
    if 'HydroFile' in line:
        HydroTemplateFile=line.split(" ")[0].strip('"')
        if(HydroTemplateFile!='unused'):
            usedFiles['HydroFile']=HydroTemplateFile
    if 'SubFile' in line:
        SubTemplateFile=line.split(" ")[0].strip('"')
        if(SubTemplateFile!='unused'):
            usedFiles['SubFile']=SubTemplateFile
    if 'MooringFile' in line:
        MooringTemplateFile=line.split(" ")[0].strip('"')
        if(MooringTemplateFile!='unused'):
            usedFiles['MooringFile']=MooringTemplateFile
    if 'IceFile' in line:
        IceTemplateFile=line.split(" ")[0].strip('"')
        if(IceTemplateFile!='unused'):
            usedFiles['IceFile']=IceTemplateFile

print('----List of all input files----')
print(EDTemplateFile,ServoTemplateFile, InflowTemplateFile)
print(HydroTemplateFile,AeroTemplateFile)
print(Bld1TemplateFile,Bld2TemplateFile, Bld3TemplateFile)
print(SubTemplateFile,MooringTemplateFile, IceTemplateFile)


listCommonFiles=['AeroFile', 'BDBldFile(1)', 'BDBldFile(2)', 'BDBldFile(3)', 'InflowFile', 'HydroFile', 'MooringFile']
for f in usedFiles:
    if f in listCommonFiles:
        commonFiles[f]=usedFiles[f]
    else:
        alterFiles[f]=usedFiles[f]

#commonFiles=['AeroFile', 'BDBldFile(1)', 'BDBldFile(2)', 'BDBldFile(3)', 'InflowFile', 'MAP.dat', 'Hydro.dat']
#alterFiles=['ElastoDyn.dat', 'ServoDyn.dat']
print('----List of common input files----')
for f in commonFiles:
    print(f, commonFiles[f])

# for fileID in commonFiles:
#     templateFile=commonFiles[fileID]
#     filepath=os.path.join(CASEDIR, os.path.basename(templateFile))
#     if(os.path.isfile(templateFile)):
#        copyfile(templateFile,filepath)
#        # change path to new directory for later use
#        commonFiles[fileID]=filepath
#        logging.info('Copied %s to %s', templateFile, CASEDIR)

print('----List of alter input files----')
for f in alterFiles:
    print(f, alterFiles[f])
logging.info('List of files to be altered are %s : ', list(alterFiles.values()))

fh=open(EDTemplateFile, 'r')
for line in fh:
    if 'TipRad' in line:
        TipRad=float(" ".join(line.split(" ")).split()[0])
    if 'HubRad' in line:
        HubRad=float(" ".join(line.split(" ")).split()[0])
    if 'TowerHt' in line:
        TowerHt=float(" ".join(line.split(" ")).split()[0])

BladeLen  = TipRad - HubRad;

#print(CompAero, CompInflow)
print(TipRad, HubRad, TowerHt, BladeLen)

localFiles={}
# time in seconds that the first linearization output will happen (maximum time to converge to steady-state solution)
# SimTime=300; 
# RatedWindSpeed = 11.4;

for idx, RotSpeed in enumerate(RotSpeedAry):    
    print(idx,RotSpeed)
    # if (CompAero > 0):
    #     #wkSheetName=str(WindSpeedAry[idx])+'mps';
    #     wkSheetName=str(WindSpeedAry[idx])+'mps';
    # else:
    #     wkSheetName=str(RotSpeed)+'RPM'

    # create fast input file for each case in the DLC folder
    FASTFile=os.path.basename(os.path.splitext(FASTTemplateFile)[0])+'-'+str(idx)+'.fst'
    FASTFile=os.path.join(CASEDIR,FASTFile)
    if(os.path.isfile(FASTTemplateFile)):
        copyfile(FASTTemplateFile,FASTFile)
        logging.info('Copied %s to %s', FASTFile, CASEDIR)

    # change path for the common input files inside the fst file
    for fileID in commonFiles:
        SetFASTPar(FASTFile,fileID,os.path.basename(commonFiles[fileID]))

    # create new alter files and change their path inside the fst file
    for fileID in alterFiles:
        templateFile=alterFiles[fileID]
        localFiles[fileID]=os.path.basename(os.path.splitext(templateFile)[0])+'-'+str(idx)+'.dat'
        localFiles[fileID]=os.path.join(CASEDIR, os.path.basename(localFiles[fileID]))

        if(os.path.isfile(templateFile)):
           copyfile(templateFile,localFiles[fileID])
           SetFASTPar(FASTFile,fileID, os.path.basename(localFiles[fileID]));
           logging.info('Copied %s to %s', localFiles[fileID], CASEDIR)

    if (np.isclose(RotSpeed,0.001,0.001)):
        NLinTimes = 1;
    else:
        NLinTimes = 36;

    tmpLinTimes=[];
    deltaLinTimes=60.0/(RotSpeed*NLinTimes)
    for i in range(NLinTimes):
        #print(SimTime+i*deltaLinTimes)
        tmpLinTimes.append(SimTime+i*deltaLinTimes)

    #exit()
    if (WindSpeedAry[idx] > RatedWindSpeed and CompAero > 0):
        #GenTq=43094;
        GenTq=GenTqAry[idx];
        TrimCase=3;
        TrimGain=0.01;
    else:
        GenTq=GenTqAry[idx];
        TrimCase=2;
        TrimGain=100;

    if CompInflow > 0:
        logging.info('Setting WindSpeed in %s', localFiles['InflowFile'])
        SetFASTPar(localFiles['InflowFile'],'HWindSpeed',WindSpeedAry[idx])

    if CompServo > 0:
        logging.info('Setting VS_RtTq in %s', localFiles['ServoFile'])
        SetFASTPar(localFiles['ServoFile'],'VS_RtTq',GenTq)

    logging.info('Setting RotSpeed in %s', localFiles['EDFile'])
    SetFASTPar(localFiles['EDFile'],'RotSpeed',RotSpeed)

    logging.info('Setting BlPitch 1,2,3 parameters in %s', localFiles['EDFile'])
    SetFASTPar(localFiles['EDFile'],'BlPitch(1)',BldPitch1Ary[idx])
    SetFASTPar(localFiles['EDFile'],'BlPitch(2)',BldPitch1Ary[idx])
    SetFASTPar(localFiles['EDFile'],'BlPitch(3)',BldPitch1Ary[idx])

    # if CompInflow > 0:
    #     logging.info('Setting BlPitch 1,2,3 parameters in %s', localFiles['EDFile'])
    #     SetFASTPar(localFiles['EDFile'],'BlPitch(1)',BldPitch1[idx])
    #     SetFASTPar(localFiles['EDFile'],'BlPitch(2)',BldPitch1[idx])
    #     SetFASTPar(localFiles['EDFile'],'BlPitch(3)',BldPitch1[idx])

    LinTimes=' '.join(format(x, "10.4f") for x in tmpLinTimes);
    TMax=np.ceil(tmpLinTimes[-1])
    SetFASTPar(FASTFile,'TMax',TMax);
    #SetFASTPar(FASTFile,'TMax',SimTime);
    SetFASTPar(FASTFile,'Linearize','True');
    SetFASTPar(FASTFile,'NLinTimes',NLinTimes);
    SetFASTPar(FASTFile,'LinTimes',LinTimes);
    SetFASTPar(FASTFile,'CalcSteady','False');
    SetFASTPar(FASTFile,'TrimCase', TrimCase);
    SetFASTPar(FASTFile,'TrimGain', TrimGain); 
    SetFASTPar(FASTFile,'TrimTol', 1e-3);
    SetFASTPar(FASTFile,'Twr_Kdmp', 0);
    SetFASTPar(FASTFile,'Bld_Kdmp', 0);
    SetFASTPar(FASTFile,'OutFmt','"ES20.12E3"');
    # SetFASTPar(FASTFile,'WrVTK',WrVTK);


logging.info('Launching jobs!')
# launch simulations on 75 percentage of available cpus
ncores=int(0.75*multiprocessing.cpu_count())
results=[]
pool = multiprocessing.Pool(ncores) #use ncores < MAX cores (24)
for i in range(0, idx+1):
    FASTFile=os.path.splitext(FASTTemplateFile)[0]+'-'+str(i)+'.fst'
    logFile='sim-'+str(i)+'.log'
    #cmndargs=FASTFile+" 2>&1 | tee "+logFile
    cmndargs=FASTFile+"|& stdbuf -oL tr '\r' '\n' > " + logFile
    logging.info('Refer file sim-%d.log for simulation output details!',i)
    results.append(pool.apply_async(runOpenFAST, args=(cmndargs,)))
pool.close()
pool.join()

logging.info('Gathering output details from finished simulations!')
# gather all outputs/erros from the finished simulations
for result in results:
    case_args, out, err = result.get()
    case=case_args.split("|& stdbuf")[0]
    log=case_args.split("|& stdbuf -oL tr '\r' '\n' > ")[1]
    flag=False

    with open(log) as f:
        if 'OpenFAST terminated normally' in f.read():
            flag=True

    if flag:
        logging.info('Simulation case %s: PASSED!', case)
    else:
        logging.info('Simulation case %s: FAILED!, Refer %s for more details!', case,log)

logging.info('End of file!')
