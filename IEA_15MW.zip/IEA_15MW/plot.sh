
# Line style for axes
set style line 80 lt rgb "#808080"

# Line style for grid
set style line 81 lt 0  # dashed
set style line 81 lt rgb "#808080"  # grey

set grid back linestyle 81
set border 3 back linestyle 80

#set key at screen 0.1, screen 0.9
set key outside center top maxcolumns 3 maxrows 4 font ",6" box width -5
#set key outside vert right maxcolumns 1 maxrows 12 font ",10" box width -4
#set key samplen 3

set key box linestyle 80 lw 1
set xrange [0:14]
set yrange [0:3]
set ylabel "Frequencies [Hz]"
set xlabel "Rotor Speed [rpm]"

set terminal pngcairo size 600,500 enhanced font "Verdana,14"; set output "CD.png";
plot "CampbellData.csv" u 1:2 w lp t "1st Tower FA", "" u 1:3 w lp t "1st Tower SS", "" u 1:13 w lp t "2nd Tower FA" , "" u 1:14 w lp t "2nd Tower SS",  "" u 1:4 w lp t "1st Blade Flap (Regressive)", "" u 1:5 w lp t "1st Blade Flap (Collective)", "" u 1:6 w lp t "1st Blade Flap (Progressive)", "" u 1:7 w lp t "1st Blade Edge (Regressive)", "" u 1:8 w lp t "1st Blade Edge (Progressive)", "" u 1:10 w lp t "2nd Blade Flap (Regressive)", "" u 1:11 w lp t "2nd Blade Flap (Collective)", "" u 1:12 w lp t "2nd Blade Flap (Progressive)"
